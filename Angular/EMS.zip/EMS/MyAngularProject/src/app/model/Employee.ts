export class Employee{
    id : number =0;
    empName:string ="";
    empSalary:number=0;
}